import javafx.animation.Animation;
import javafx.animation.FadeTransition;
import javafx.animation.ParallelTransition;
import javafx.animation.PathTransition;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;

public class HelloFX extends Application {

    @Override
    public void start(Stage primaryStage) {
        Pane pane = new Pane();

        Polygon pentagon = new Polygon();
        pentagon.getPoints().addAll(new Double[]{
            200.0, 50.0, 
            350.0, 160.0, 
            290.0, 340.0,  
            110.0, 340.0,  
            50.0, 160.0    
        });
        pentagon.setFill(Color.TRANSPARENT);
        pentagon.setStroke(Color.DARKSLATEBLUE);
        pentagon.setStrokeWidth(3);

        Rectangle rect = new Rectangle(0, 0, 40, 20);
        rect.setFill(Color.ORANGE);
        rect.setStroke(Color.DARKRED);

        PathTransition pathTransition = new PathTransition();
        pathTransition.setDuration(Duration.seconds(6));
        pathTransition.setPath(pentagon);
        pathTransition.setNode(rect);
        pathTransition.setOrientation(PathTransition.OrientationType.ORTHOGONAL_TO_TANGENT);
        pathTransition.setCycleCount(Animation.INDEFINITE);

        FadeTransition fadeTransition = new FadeTransition(Duration.seconds(3), rect);
        fadeTransition.setFromValue(1.0);
        fadeTransition.setToValue(0.1);
        fadeTransition.setAutoReverse(true);
        fadeTransition.setCycleCount(Animation.INDEFINITE);

        ParallelTransition parallelTransition = new ParallelTransition(pathTransition, fadeTransition);

        pane.setOnMouseClicked(event -> {
            if (event.getButton() == MouseButton.PRIMARY) {
                parallelTransition.play();
            } else if (event.getButton() == MouseButton.SECONDARY) {
                parallelTransition.pause();
            }
        });

        pane.getChildren().addAll(pentagon, rect);
        Scene scene = new Scene(pane, 400, 400);
        
        primaryStage.setTitle("Pentagon Path Animation");
        primaryStage.setScene(scene);
        primaryStage.show();

        parallelTransition.play();
    }
    public static void main(String[] args) {
        launch(args);
    }
}